# Technology Stack

Frontend
- React
- Tailwind CSS

Backend
- FastAPI
- Python

AI
- LangGraph
- Gemini

Database
- PostgreSQL

Deployment
- Render

Container
- Docker
