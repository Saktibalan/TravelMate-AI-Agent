# TravelMate AI

## Project Description
TravelMate AI is a multi-agent AI-powered travel planning system that generates personalized travel itineraries based on user preferences, budget, and travel dates.

## Features
- Personalized itinerary
- Flight recommendations
- Hotel recommendations
- Budget planning
- Weather information
- Tourist attractions

## Tech Stack
- React
- FastAPI
- Python
- LangGraph
- PostgreSQL
- Gemini
- Tailwind CSS
- Docker
- Render

## Demo
https://amazing-churros-516a77.netlify.app/
