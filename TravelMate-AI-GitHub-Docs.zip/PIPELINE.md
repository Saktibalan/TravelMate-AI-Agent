# Pipeline

User Input
↓
React
↓
FastAPI
↓
LangGraph
↓
AI Agents
↓
External APIs
↓
Gemini
↓
JSON
↓
Frontend
