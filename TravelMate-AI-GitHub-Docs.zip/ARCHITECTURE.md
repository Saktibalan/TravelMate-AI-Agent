# Architecture

User
↓
React
↓
FastAPI
↓
LangGraph
↓
Memory Agent
Research Agent
Flight Agent
Hotel Agent
Itinerary Agent
Budget Agent
↓
Gemini
↓
PostgreSQL
↓
JSON
↓
React UI
